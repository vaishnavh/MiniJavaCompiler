class Test6{
    public static void main(String[] a){
        System.out.println(1);
    }
}

//take 2 ints and return a boolean
//2 errors - 1. < does not take int and int, in case 2. returns int instead of bool
class Finder {
    public int Find(int a,int num){
        if(true<num){
	}
	else
	{
	}
	a = num < num;
	return 0;
    }
}
