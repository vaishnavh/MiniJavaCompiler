class CoinToss {
  public static void main(String[] a){
    System.out.println(new Coin().toss());
  }
}

class Coin {
  public int toss() {
    boolean isHead;
    isHead = 1;
    if (isHead)
    {
    	ishead = true;
    }
    
    else
    {
    	ishead = true;
    } 
    
    return 1;
    
  }
}
