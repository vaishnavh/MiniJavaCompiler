/*
7. The + operator should take two integer operators and return an integer.
*/

class seven{
	public static void main(String[] a){
		System.out.println(new simpleAdd().add(2));
	}
}

class simpleAdd{

	public int add(int num){
		int y;
		boolean z;
		z=true;
		y = num+z;
		return y;
	}
}