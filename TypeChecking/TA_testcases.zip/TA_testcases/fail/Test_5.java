class Test5{
    public static void main(String[] a){
        System.out.println(1);
    }
}

//and operator does not 1. take bool operators, 2. return a bool
class Finder {
    public int Find(int a,int num){
	int i;
	if(a & num){
	}
	else
	{
	}
	i = true & true;
	return 0;
    }
}
