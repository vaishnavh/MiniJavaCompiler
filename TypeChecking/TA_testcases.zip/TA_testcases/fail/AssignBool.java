class AssignBool 
{
	public static void main(String[] args) 
	{
		System.out.println(new Ss().Compute(true, 11));
	}
}

class Ss
{
	public int Compute(boolean flag, int num2)
	{
		int y;
		flag = y;
		return num;
	}
}
