//* operator
class pgm1{
    public static void main(String[] a){
        System.out.println(new somename().foo());
    }
}

class somename {
    public int foo(){
        float a;
        boolean b;
        a=a*b;
        return 0;
    }
}
