//new int [Expression] -- Expression must be integer.

class pgm4{
    public static void main(String[] a){
        System.out.println(new somename().foo(5));
    }
}

class somename {
    int[] a;
    boolean b;
    public int foo(int size){
        a=new int[b];
        return 0;
    }
}
