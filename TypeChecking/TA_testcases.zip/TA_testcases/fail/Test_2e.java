class Test2e{
    public static void main(String[] a){
        System.out.println(1);
    }
}


class Finder {
    public int Find(int a,int num){
        int i;
	int[] arr;
	arr[0] = true;
	i[2] = a; 
	return 0;
    }
}

