//.length operator
class pgm4{
    public static void main(String[] a){
        System.out.println(new somename().foo(5));
    }
}

class somename {
    int b;
    public int foo(int size){
        b=true.length;
        return 0;
    }
}
