class AssignInt 
{
	public static void main(String[] args) 
	{
		System.out.println(new Ss().Compute(10, 11));
	}
}

class Ss
{
	public int Compute(int num, int num2)
	{
		boolean x;
		int y;
		x = false;
		
		num = ((x) * y);
		return num;
	}
}
