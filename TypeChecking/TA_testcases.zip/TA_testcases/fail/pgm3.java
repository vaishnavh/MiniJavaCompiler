//The array dereference operator [] -- the array should be of type int [], and the index should be of type int.

class pgm3{
    public static void main(String[] a){
        System.out.println(new somename().foo(5));
    }
}

class somename {
    int[] a;
    boolean b;
    public int foo(int size){
        a=new int[size];
        a[b]=a[b];
        return 0;
    }
}
