class PrintCheck 
{
	public static void main(String[] args) 
	{
		System.out.println(new Ss().Compute(10, 11, true));
	}
}

class Ss
{
	public boolean Compute(int num, int num2, boolean flag)
	{
		return flag;
	}
}
