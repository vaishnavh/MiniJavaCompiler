class Test4{
    public static void main(String[] a){
        System.out.println(1);
    }
}

class Finder {
    public int Find(int a,int num){
        while(num){
	}
	return 0;
    }
}
