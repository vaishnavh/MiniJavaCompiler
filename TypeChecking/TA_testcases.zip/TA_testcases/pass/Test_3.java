class Test3{
    public static void main(String[] a){
        System.out.println(1);
    }
}


class Finder {
    public int Find(int a,int num){
        if(true){
	}
	else
	{
	}
	return 0;
    }
}
