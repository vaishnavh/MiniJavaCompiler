class ArrayLength {
    public static void main(String[] a){
        System.out.println(new Fac().Compute());
    }
}

class Fac {
    public int Compute() {
        int[] num_aux;
        return num_aux.length;
    }
}

