class CoinToss {
  public static void main(String[] a){
    System.out.println(new Coin().toss());
  }
}

class Coin {
  public int toss() {
    boolean isHead;
    isHead = true;
    if(isHead)
    {
    	isHead = true;
    }
    
    else
    {
    	isHead = true;
    }
     
     return 0;
  }
}
