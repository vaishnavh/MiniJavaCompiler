class AssignInt 
{
	public static void main(String[] args) 
	{
		System.out.println(new Ss().Compute(10, 11));
	}
}

class Ss
{
	public int Compute(int num, int num2)
	{
		int x;
		int y;
		x = 10;
		
		num = (x + (y));
		return num;
	}
}
