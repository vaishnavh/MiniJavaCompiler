// Pass

class AssignArray 
{
	public static void main(String[] args) 
	{
		System.out.println(new Ss().Compute(true));
	}
}

class Ss
{
	int[] number;
	public int Compute(boolean flag)
	{
		int i;
		int []a;
		number[i] = a[5];
		return 10;
	}
}
