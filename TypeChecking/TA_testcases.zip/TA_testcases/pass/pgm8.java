//! (Expr) -- Expr must be boolean.


class pgm8{
    public static void main(String[] a){
        System.out.println(new somename().init(6));
    }
}

class somename {
    public int init(int size){
	boolean a;
	a=true;
	a = !(a);
	return 0 ;
    }
   
}
