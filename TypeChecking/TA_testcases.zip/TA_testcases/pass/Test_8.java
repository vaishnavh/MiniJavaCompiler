class Test8{
    public static void main(String[] a){
        System.out.println(1);
    }
}

class Finder {
    public int Find(int a,int num){
        int i;
	i = a-num;
	return 0;
    }
}
