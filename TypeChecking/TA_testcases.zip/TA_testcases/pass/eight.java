/*
8. The - operator should take two integer operators and return an integer.
*/

class eight{
	public static void main(String[] a){
		System.out.println(new simpleSub().sub(2));
	}
}

class simpleSub{

	public int sub(int num){
		int y;
		y=num-num;
		return y;
	}
}