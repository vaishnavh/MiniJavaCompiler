class Test2c{
    public static void main(String[] a){
        System.out.println(1);
    }
}

//LHS and RHS must be int[]
class Finder {
    public int Find(int a,int num){
        int i;
	int[] firstNumNos;
	int[] secondNumNos;
	firstNumNos = secondNumNos;
	return 0;
    }
}
