class Test6{
    public static void main(String[] a){
        System.out.println(1);
    }
}

//take 2 ints and return a boolean
class Finder {
    public int Find(int a,int num){
        if(a<num){
	}
	else
	{
	}
	return 0;
    }
}
