/*
9. The * operator should take two integer operators and return an integer.
*/

class nine{
	public static void main(String[] a){
		System.out.println(new simpleMul().mult(2));
	}
}

class simpleMul{

	public int mult(int num){
		int y;
		y=num*num;
		return y;
	}
}
