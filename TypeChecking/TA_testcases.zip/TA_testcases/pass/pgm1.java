class pass_1{
    public static void main(String[] a){
        System.out.println(new somename().foo(8,6));
    }
}

class somename {
    public int foo(int a1,int a2){
        a2=a1*a2;
        return 0;
    }
}
