class Test2d{
    public static void main(String[] a){
        System.out.println(1);
    }
}


class Finder {
    public int Find(int a,int num){
        int i;
	Aux aux1;
	Aux aux2;
	//aux1 = new Aux();
	//aux2 = new Aux();
	aux1 = aux2;
	return 0;
    }
}

class Aux {
    int x; 

}
